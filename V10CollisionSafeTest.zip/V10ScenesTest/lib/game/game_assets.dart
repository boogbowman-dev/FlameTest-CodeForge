class GameAssets {
  GameAssets._();

  // Flame's image loader is rooted at assets/images/.
  static const String playerSprite = 'player.png';

  // Reserved for the next V10 audio milestone.
  static const String audioDirectory = 'assets/audio/';
}
