# V10ScenesFixFlame

Flutter + Flame game source created on-device by CodeForge V10.2.

## V10.2 playable milestone

- Menu, gameplay, and game-over scenes are generated.
- `RouterComponent` manages named scene navigation.
- Level One keeps the draggable player and collision walls.
- `Player` has an active rectangle hitbox.
- Generated walls have passive rectangle hitboxes.
- The screen edge is protected by `ScreenHitbox`.
- `assets/images/` and `assets/audio/` remain registered.
- Add `assets/images/player.png` to replace the fallback player.
- See `ASSETS.md`, `COLLISIONS.md`, and `SCENES.md`.

## Project identity

- Dart package: `cf_game_v10scenesfixflame`
- Organization: `com.codeforge.generated`
- Planned Android application ID: `com.codeforge.generated.cf_game_v10scenesfixflame`
- Flame: `^1.38.2`

## Build with official Flutter

```bash
bash tool/bootstrap_android.sh
flutter build apk --release
```

GitHub Actions remains available at `.github/workflows/flame-android.yml`.

## Next V10 milestones

Audio playback and reusable game templates can now build on the scene system.
