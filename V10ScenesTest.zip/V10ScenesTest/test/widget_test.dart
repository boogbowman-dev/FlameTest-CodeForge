import 'package:flame/game.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:cf_game_v10scenestest/main.dart';

void main() {
  testWidgets('creates the CodeForge game widget', (tester) async {
    await tester.pumpWidget(const CodeForgeFlameApp());
    expect(find.byType(GameWidget), findsOneWidget);
  });
}
