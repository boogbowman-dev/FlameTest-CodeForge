import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flutter/material.dart';
import '../codeforge_game.dart';
import '../game_assets.dart';
import '../player.dart';
import '../wall.dart';

class LevelOneScene extends Component with HasGameReference<CodeForgeGame> {
  @override
  Future<void> onLoad() async {
    await super.onLoad();

    final walls = <Wall>[
      Wall(
        position: Vector2(game.size.x * 0.10, game.size.y * 0.38),
        size: Vector2(game.size.x * 0.42, 28),
      ),
      Wall(
        position: Vector2(game.size.x * 0.52, game.size.y * 0.62),
        size: Vector2(game.size.x * 0.36, 28),
      ),
    ];

    await addAll(walls);

    Sprite? playerSprite;
    try {
      playerSprite = await game.loadSprite(GameAssets.playerSprite);
    } catch (_) {
      playerSprite = null;
    }

    final player = Player(sprite: playerSprite)
      ..position = game.size / 2;
    await add(player);

    await add(
      TextComponent(
        text: 'LEVEL ONE',
        position: Vector2(20, 30),
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );

    await add(
      _FinishButton(
        position: Vector2(game.size.x - 110, 55),
        onPressed: () => game.router.pushReplacementNamed('game-over'),
      ),
    );
  }
}

class _FinishButton extends RectangleComponent with TapCallbacks {
  _FinishButton({
    required Vector2 position,
    required this.onPressed,
  }) : super(
          position: position,
          size: Vector2(180, 52),
          anchor: Anchor.center,
          paint: Paint()..color = const Color(0xFF5D3FD3),
        );

  final VoidCallback onPressed;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    await add(
      TextComponent(
        text: 'FINISH LEVEL',
        position: size / 2,
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  @override
  void onTapUp(TapUpEvent event) {
    onPressed();
  }
}
