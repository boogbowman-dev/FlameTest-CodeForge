import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'game/codeforge_game.dart';

void main() {
  runApp(const CodeForgeFlameApp());
}

class CodeForgeFlameApp extends StatelessWidget {
  const CodeForgeFlameApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: Scaffold(
        body: Stack(
          children: [
            Positioned.fill(
              child: GameWidget.controlled(gameFactory: CodeForgeGame.new),
            ),
            const SafeArea(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('FlameTest', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                    SizedBox(height: 6),
                    Text('Drag the cyan square around the game field.'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
