import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'player.dart';

class CodeForgeGame extends FlameGame {
  final Player player = Player();

  @override
  Color backgroundColor() => const Color(0xFF071017);

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    player.position = size / 2;
    await add(player);
  }
}
