import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flutter/material.dart';

class Player extends RectangleComponent with DragCallbacks {
  Player()
      : super(
          size: Vector2.all(72),
          anchor: Anchor.center,
          paint: Paint()..color = const Color(0xFF29C7FF),
        );

  @override
  void onDragUpdate(DragUpdateEvent event) {
    position += event.localDelta;
  }
}
