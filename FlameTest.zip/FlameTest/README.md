# FlameTest

Flutter + Flame game source created on-device by CodeForge.

## First playable milestone

- `CodeForgeGame` extends `FlameGame`.
- `GameWidget` embeds the game in Flutter.
- `Player` is a draggable cyan `RectangleComponent`.
- No external art assets are required for this first test.

## Project identity

- Dart package: `cf_game_flametest`
- Organization: `com.codeforge.generated`
- Planned Android application ID: `com.codeforge.generated.cf_game_flametest`
- Flame: `^1.38.2`

## Build with official Flutter

On a supported Flutter host or CI runner:

```bash
bash tool/bootstrap_android.sh
flutter build apk --release
```

A GitHub Actions workflow is included at `.github/workflows/flame-android.yml`.
If a phone browser upload flattens folders, recreate that workflow path in GitHub before running it.

This first Flame project is for build/input verification. Sprites, collisions, scenes, audio, and game templates come after this APK is proven.
