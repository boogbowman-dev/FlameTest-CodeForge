import 'package:flutter_test/flutter_test.dart';
import 'package:cf_game_flametest/main.dart';

void main() {
  testWidgets('shows Flame game instructions', (tester) async {
    await tester.pumpWidget(const CodeForgeFlameApp());
    expect(find.text('Drag the cyan square around the game field.'), findsOneWidget);
  });
}
