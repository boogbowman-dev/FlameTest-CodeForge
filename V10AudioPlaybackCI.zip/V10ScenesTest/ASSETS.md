# CodeForge V10 Assets

This generated game is ready for real artwork while still running without it.

## Player sprite

Place a PNG named `player.png` here:

`assets/images/player.png`

The generated `CodeForgeGame` attempts to load that sprite at startup. If the file is missing, the player remains a rounded cyan fallback shape so the project still builds and runs.

Recommended first test: 72x72 or 144x144 PNG with transparency.

## More images

Add additional art under `assets/images/`. The whole directory is already registered in `pubspec.yaml`.

## Audio

Put future sound and music assets under `assets/audio/`. The directory is registered now so V10 can add playback support without reorganizing generated projects later.

## Code entry points

- `lib/game/game_assets.dart` keeps generated asset names in one place.
- `lib/game/codeforge_game.dart` loads the player sprite.
- `lib/game/player.dart` renders the sprite or the fallback shape.
