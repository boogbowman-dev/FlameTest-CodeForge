import 'package:flame_audio/flame_audio.dart';
import 'game_assets.dart';

class GameAudio {
  GameAudio._();

  static bool _bgmInitialized = false;
  static bool _menuMusicPlaying = false;

  static Future<void> _ensureBgmInitialized() async {
    if (_bgmInitialized) return;
    try {
      await FlameAudio.bgm.initialize();
      _bgmInitialized = true;
    } catch (_) {
      _bgmInitialized = false;
    }
  }

  static Future<void> playButton() async {
    try {
      await FlameAudio.play(GameAssets.buttonSound);
    } catch (_) {}
  }

  static Future<void> playLevelComplete() async {
    try {
      await FlameAudio.play(GameAssets.levelCompleteSound);
    } catch (_) {}
  }

  static Future<void> startMenuMusic() async {
    if (_menuMusicPlaying) return;
    await _ensureBgmInitialized();
    if (!_bgmInitialized) return;
    try {
      await FlameAudio.bgm.play(GameAssets.menuMusic, volume: 0.30);
      _menuMusicPlaying = true;
    } catch (_) {
      _menuMusicPlaying = false;
    }
  }

  static Future<void> stopMenuMusic() async {
    if (!_bgmInitialized) return;
    try {
      await FlameAudio.bgm.stop();
    } catch (_) {}
    _menuMusicPlaying = false;
  }

  static Future<void> dispose() async {
    if (!_bgmInitialized) return;
    try {
      await FlameAudio.bgm.dispose();
    } catch (_) {}
    _bgmInitialized = false;
    _menuMusicPlaying = false;
  }
}
