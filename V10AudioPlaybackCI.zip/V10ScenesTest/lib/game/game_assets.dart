class GameAssets {
  GameAssets._();

  // Flame's image loader is rooted at assets/images/.
  static const String playerSprite = 'player.png';

  // Flame Audio is rooted at assets/audio/.
  static const String menuMusic = 'menu_music.mp3';
  static const String buttonSound = 'button.mp3';
  static const String levelCompleteSound = 'level_complete.mp3';
}
