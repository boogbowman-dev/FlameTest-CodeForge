import 'package:flame/collisions.dart';
import 'package:flame/game.dart';
import 'game_audio.dart';
import 'scenes/game_over_scene.dart';
import 'scenes/level_one_scene.dart';
import 'scenes/menu_scene.dart';

class CodeForgeGame extends FlameGame with HasCollisionDetection {
  late final RouterComponent router;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    await add(ScreenHitbox());

    router = RouterComponent(
      initialRoute: 'menu',
      routes: {
        'menu': Route(MenuScene.new),
        'level-one': Route(LevelOneScene.new, maintainState: false),
        'game-over': Route(GameOverScene.new, maintainState: false),
      },
    );

    await add(router);
  }

  @override
  void onDispose() {
    GameAudio.dispose();
    super.onDispose();
  }
}
