import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flutter/material.dart';
import 'wall.dart';

class Player extends PositionComponent
    with DragCallbacks, CollisionCallbacks {
  final Sprite? sprite;
  final List<Wall> walls;
  final Paint _fallbackPaint = Paint()..color = const Color(0xFF29C7FF);
  late final Vector2 _lastSafePosition;

  Player({this.sprite, required this.walls})
      : super(
          size: Vector2.all(72),
          anchor: Anchor.center,
        );

  bool get isUsingSprite => sprite != null;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _lastSafePosition = position.clone();
    await add(RectangleHitbox(collisionType: CollisionType.active));
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final activeSprite = sprite;
    if (activeSprite != null) {
      activeSprite.render(canvas, size: size);
      return;
    }

    final rect = Rect.fromLTWH(0, 0, size.x, size.y);
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(14)),
      _fallbackPaint,
    );
  }

  bool _collidesWithWall(Vector2 target) {
    final playerRect = Rect.fromCenter(
      center: Offset(target.x, target.y),
      width: size.x,
      height: size.y,
    );
    for (final wall in walls) {
      final wallRect = Rect.fromLTWH(
        wall.position.x,
        wall.position.y,
        wall.size.x,
        wall.size.y,
      );
      if (playerRect.overlaps(wallRect)) {
        return true;
      }
    }
    return false;
  }

  @override
  void onDragUpdate(DragUpdateEvent event) {
    _lastSafePosition.setFrom(position);
    final delta = event.localDelta;

    final xTarget = position + Vector2(delta.x, 0);
    if (!_collidesWithWall(xTarget)) {
      position.x = xTarget.x;
    }

    final yTarget = position + Vector2(0, delta.y);
    if (!_collidesWithWall(yTarget)) {
      position.y = yTarget.y;
    }
  }

  @override
  void onCollision(
    Set<Vector2> intersectionPoints,
    PositionComponent other,
  ) {
    if (other is Wall || other is ScreenHitbox) {
      position.setFrom(_lastSafePosition);
    }
    super.onCollision(intersectionPoints, other);
  }
}
