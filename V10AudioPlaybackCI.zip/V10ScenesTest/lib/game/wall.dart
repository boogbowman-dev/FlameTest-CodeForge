import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';

class Wall extends RectangleComponent with CollisionCallbacks {
  Wall({
    required Vector2 position,
    required Vector2 size,
  }) : super(
          position: position,
          size: size,
          paint: Paint()..color = const Color(0xFF7C4DFF),
        );

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    await add(
      RectangleHitbox(collisionType: CollisionType.passive),
    );
  }
}
