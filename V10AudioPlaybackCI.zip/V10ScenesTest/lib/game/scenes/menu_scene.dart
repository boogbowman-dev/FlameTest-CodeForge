import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flutter/material.dart';
import '../codeforge_game.dart';
import '../game_audio.dart';

class MenuScene extends Component with HasGameReference<CodeForgeGame> {
  @override
  Future<void> onLoad() async {
    await super.onLoad();
    GameAudio.startMenuMusic();

    await add(
      TextComponent(
        text: 'CodeForge Game',
        position: Vector2(game.size.x / 2, game.size.y * 0.30),
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 34,
            fontWeight: FontWeight.bold,
            color: Color(0xFF29C7FF),
          ),
        ),
      ),
    );

    await add(
      _SceneButton(
        text: 'START LEVEL',
        position: game.size / 2,
        onPressed: () {
          GameAudio.playButton();
          GameAudio.stopMenuMusic();
          game.router.pushReplacementNamed('level-one');
        },
      ),
    );
  }
}

class _SceneButton extends RectangleComponent with TapCallbacks {
  _SceneButton({
    required this.text,
    required Vector2 position,
    required this.onPressed,
  }) : super(
          position: position,
          size: Vector2(220, 64),
          anchor: Anchor.center,
          paint: Paint()..color = const Color(0xFF143246),
        );

  final String text;
  final VoidCallback onPressed;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    await add(
      TextComponent(
        text: text,
        position: size / 2,
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  @override
  void onTapUp(TapUpEvent event) {
    onPressed();
  }
}
