import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flutter/material.dart';
import '../codeforge_game.dart';
import '../game_audio.dart';

class GameOverScene extends Component with HasGameReference<CodeForgeGame> {
  @override
  Future<void> onLoad() async {
    await super.onLoad();
    GameAudio.playLevelComplete();

    await add(
      TextComponent(
        text: 'LEVEL COMPLETE',
        position: Vector2(game.size.x / 2, game.size.y * 0.32),
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
            color: Color(0xFFFF7A59),
          ),
        ),
      ),
    );

    await add(
      _GameOverButton(
        text: 'PLAY AGAIN',
        position: Vector2(game.size.x / 2, game.size.y * 0.50),
        onPressed: () {
          GameAudio.playButton();
          game.router.pushReplacementNamed('level-one');
        },
      ),
    );

    await add(
      _GameOverButton(
        text: 'MAIN MENU',
        position: Vector2(game.size.x / 2, game.size.y * 0.62),
        onPressed: () {
          GameAudio.playButton();
          game.router.pushReplacementNamed('menu');
        },
      ),
    );
  }
}

class _GameOverButton extends RectangleComponent with TapCallbacks {
  _GameOverButton({
    required this.text,
    required Vector2 position,
    required this.onPressed,
  }) : super(
          position: position,
          size: Vector2(220, 58),
          anchor: Anchor.center,
          paint: Paint()..color = const Color(0xFF143246),
        );

  final String text;
  final VoidCallback onPressed;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    await add(
      TextComponent(
        text: text,
        position: size / 2,
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  @override
  void onTapUp(TapUpEvent event) {
    onPressed();
  }
}
