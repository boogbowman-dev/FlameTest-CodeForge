# CodeForge V10.2 Collisions

Generated Flame games include collision-ready components.

## Included collision system

- `CodeForgeGame` uses `HasCollisionDetection`.
- `Player` has an active `RectangleHitbox`.
- `Wall` uses a passive `RectangleHitbox`.
- `ScreenHitbox` protects the outside edge of the game field.
- Dragging into a wall or screen edge restores the player's last safe position.

## Level placement

Walls and the player are placed by `lib/game/scenes/level_one_scene.dart`.

Add more `Wall` instances there to build larger obstacle layouts.
