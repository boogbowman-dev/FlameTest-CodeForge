# CodeForge V10.2 Scenes

Generated games now use Flame's `RouterComponent` for scene navigation.

## Generated scenes

- `menu_scene.dart` - starting menu and Start Level button.
- `level_one_scene.dart` - player, walls, collisions, and Finish Level button.
- `game_over_scene.dart` - Play Again and Main Menu actions.

## Routes

Routes are declared in `lib/game/codeforge_game.dart` using the names:

- `menu`
- `level-one`
- `game-over`

Use `game.router.pushReplacementNamed(...)` to switch full-screen scenes.

This structure is ready for future level selection, pause screens, settings, inventory screens, dialogue, and additional generated levels.
