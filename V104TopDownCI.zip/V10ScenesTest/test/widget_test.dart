import 'package:flutter_test/flutter_test.dart';
import 'package:cf_game_v104topdown/main.dart';

void main() {
  test('creates the CodeForge app', () {
    final app = const CodeForgeFlameApp();
    expect(app, isA<CodeForgeFlameApp>());
  });
}
