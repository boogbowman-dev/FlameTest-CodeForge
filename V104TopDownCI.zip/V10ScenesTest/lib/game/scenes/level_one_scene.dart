import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flutter/material.dart';
import '../codeforge_game.dart';
import '../game_assets.dart';
import '../game_audio.dart';
import '../player.dart';
import '../wall.dart';

class LevelOneScene extends Component with HasGameReference<CodeForgeGame> {
  @override
  Future<void> onLoad() async {
    await super.onLoad();

    await add(
      RectangleComponent(
        size: game.size,
        paint: Paint()..color = const Color(0xFF0D241D),
      ),
    );

    final walls = <Wall>[
      Wall(
        position: Vector2(game.size.x * 0.08, game.size.y * 0.27),
        size: Vector2(game.size.x * 0.42, 24),
      ),
      Wall(
        position: Vector2(game.size.x * 0.58, game.size.y * 0.30),
        size: Vector2(24, game.size.y * 0.24),
      ),
      Wall(
        position: Vector2(game.size.x * 0.18, game.size.y * 0.52),
        size: Vector2(game.size.x * 0.46, 24),
      ),
      Wall(
        position: Vector2(game.size.x * 0.74, game.size.y * 0.60),
        size: Vector2(24, game.size.y * 0.20),
      ),
    ];

    await addAll(walls);

    Sprite? playerSprite;
    try {
      playerSprite = await game.loadSprite(GameAssets.playerSprite);
    } catch (_) {
      playerSprite = null;
    }

    final player = Player(
      sprite: playerSprite,
      walls: walls,
    )..position = Vector2(
        game.size.x * 0.18,
        game.size.y * 0.78,
      );
    await add(player);

    await add(
      TextComponent(
        text: 'OUTPOST ONE',
        position: Vector2(20, 28),
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Color(0xFF55E6A5),
          ),
        ),
      ),
    );

    await add(
      _ExitButton(
        position: Vector2(game.size.x - 95, 55),
        onPressed: () {
          GameAudio.playButton();
          game.router.pushReplacementNamed('game-over');
        },
      ),
    );
  }
}

class _ExitButton extends RectangleComponent with TapCallbacks {
  _ExitButton({
    required Vector2 position,
    required this.onPressed,
  }) : super(
          position: position,
          size: Vector2(150, 50),
          anchor: Anchor.center,
          paint: Paint()..color = const Color(0xFF174C3C),
        );

  final VoidCallback onPressed;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    await add(
      TextComponent(
        text: 'EXIT',
        position: size / 2,
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  @override
  void onTapUp(TapUpEvent event) {
    onPressed();
  }
}
