import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flutter/material.dart';
import '../codeforge_game.dart';
import '../game_assets.dart';
import '../game_audio.dart';
import '../player.dart';
import '../wall.dart';

class LevelOneScene extends Component with HasGameReference<CodeForgeGame> {
  @override
  Future<void> onLoad() async {
    await super.onLoad();

    await add(
      RectangleComponent(
        size: game.size,
        paint: Paint()..color = const Color(0xFF17131F),
      ),
    );

    final platforms = <Wall>[
      Wall(
        position: Vector2(0, game.size.y * 0.78),
        size: Vector2(game.size.x, 30),
      ),
      Wall(
        position: Vector2(game.size.x * 0.18, game.size.y * 0.60),
        size: Vector2(game.size.x * 0.28, 24),
      ),
      Wall(
        position: Vector2(game.size.x * 0.55, game.size.y * 0.47),
        size: Vector2(game.size.x * 0.28, 24),
      ),
      Wall(
        position: Vector2(game.size.x * 0.28, game.size.y * 0.33),
        size: Vector2(game.size.x * 0.26, 24),
      ),
    ];

    await addAll(platforms);

    Sprite? playerSprite;
    try {
      playerSprite = await game.loadSprite(GameAssets.playerSprite);
    } catch (_) {
      playerSprite = null;
    }

    final player = Player(
      sprite: playerSprite,
      platforms: platforms,
      worldSize: game.size,
    )..position = Vector2(
        game.size.x * 0.15,
        game.size.y * 0.68,
      );
    await add(player);

    await add(
      TextComponent(
        text: 'PLATFORM RUN',
        position: Vector2(20, 28),
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Color(0xFFFFB74D),
          ),
        ),
      ),
    );

    await add(
      _FinishRunButton(
        position: Vector2(game.size.x - 92, 52),
        onPressed: () {
          GameAudio.playButton();
          game.router.pushReplacementNamed('game-over');
        },
      ),
    );

    await add(
      _HoldButton(
        text: 'LEFT',
        position: Vector2(70, game.size.y - 55),
        onPressed: () => player.setMoveDirection(-1),
        onReleased: () => player.setMoveDirection(0),
      ),
    );

    await add(
      _HoldButton(
        text: 'RIGHT',
        position: Vector2(180, game.size.y - 55),
        onPressed: () => player.setMoveDirection(1),
        onReleased: () => player.setMoveDirection(0),
      ),
    );

    await add(
      _JumpButton(
        position: Vector2(game.size.x - 75, game.size.y - 55),
        onPressed: player.jump,
      ),
    );
  }
}

class _HoldButton extends RectangleComponent with TapCallbacks {
  _HoldButton({
    required this.text,
    required Vector2 position,
    required this.onPressed,
    required this.onReleased,
  }) : super(
          position: position,
          size: Vector2(96, 54),
          anchor: Anchor.center,
          paint: Paint()..color = const Color(0xFF5A3A12),
        );

  final String text;
  final VoidCallback onPressed;
  final VoidCallback onReleased;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    await add(
      TextComponent(
        text: text,
        position: size / 2,
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  @override
  void onTapDown(TapDownEvent event) {
    onPressed();
  }

  @override
  void onTapUp(TapUpEvent event) {
    onReleased();
  }

  @override
  void onTapCancel(TapCancelEvent event) {
    onReleased();
  }
}

class _JumpButton extends RectangleComponent with TapCallbacks {
  _JumpButton({
    required Vector2 position,
    required this.onPressed,
  }) : super(
          position: position,
          size: Vector2(118, 54),
          anchor: Anchor.center,
          paint: Paint()..color = const Color(0xFFB26A00),
        );

  final VoidCallback onPressed;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    await add(
      TextComponent(
        text: 'JUMP',
        position: size / 2,
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  @override
  void onTapDown(TapDownEvent event) {
    onPressed();
  }
}

class _FinishRunButton extends RectangleComponent with TapCallbacks {
  _FinishRunButton({
    required Vector2 position,
    required this.onPressed,
  }) : super(
          position: position,
          size: Vector2(150, 50),
          anchor: Anchor.center,
          paint: Paint()..color = const Color(0xFFB26A00),
        );

  final VoidCallback onPressed;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    await add(
      TextComponent(
        text: 'FINISH RUN',
        position: size / 2,
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  @override
  void onTapUp(TapUpEvent event) {
    onPressed();
  }
}
