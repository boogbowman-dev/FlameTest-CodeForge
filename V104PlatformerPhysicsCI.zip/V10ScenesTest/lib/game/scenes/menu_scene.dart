import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flutter/material.dart';
import '../codeforge_game.dart';
import '../game_audio.dart';

class MenuScene extends Component with HasGameReference<CodeForgeGame> {
  @override
  Future<void> onLoad() async {
    await super.onLoad();
    GameAudio.startMenuMusic();

    await add(
      TextComponent(
        text: 'PLATFORMER',
        position: Vector2(game.size.x / 2, game.size.y * 0.27),
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 34,
            fontWeight: FontWeight.bold,
            color: Color(0xFFFFB74D),
          ),
        ),
      ),
    );

    await add(
      TextComponent(
        text: 'Run, jump, and climb to the goal.',
        position: Vector2(game.size.x / 2, game.size.y * 0.37),
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 14,
            color: Colors.white70,
          ),
        ),
      ),
    );

    await add(
      _PlatformerButton(
        text: 'START RUN',
        position: Vector2(game.size.x / 2, game.size.y * 0.55),
        onPressed: () {
          GameAudio.playButton();
          GameAudio.stopMenuMusic();
          game.router.pushReplacementNamed('level-one');
        },
      ),
    );
  }
}

class _PlatformerButton extends RectangleComponent with TapCallbacks {
  _PlatformerButton({
    required this.text,
    required Vector2 position,
    required this.onPressed,
  }) : super(
          position: position,
          size: Vector2(220, 64),
          anchor: Anchor.center,
          paint: Paint()..color = const Color(0xFF5A3A12),
        );

  final String text;
  final VoidCallback onPressed;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    await add(
      TextComponent(
        text: text,
        position: size / 2,
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  @override
  void onTapUp(TapUpEvent event) {
    onPressed();
  }
}
