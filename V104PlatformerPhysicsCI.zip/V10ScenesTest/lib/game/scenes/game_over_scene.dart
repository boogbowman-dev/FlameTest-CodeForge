import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flutter/material.dart';
import '../codeforge_game.dart';
import '../game_audio.dart';

class GameOverScene extends Component with HasGameReference<CodeForgeGame> {
  @override
  Future<void> onLoad() async {
    await super.onLoad();
    GameAudio.playLevelComplete();

    await add(
      TextComponent(
        text: 'RUN COMPLETE',
        position: Vector2(game.size.x / 2, game.size.y * 0.30),
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
            color: Color(0xFFFFB74D),
          ),
        ),
      ),
    );

    await add(
      TextComponent(
        text: 'You reached the finish.',
        position: Vector2(game.size.x / 2, game.size.y * 0.39),
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 15,
            color: Colors.white70,
          ),
        ),
      ),
    );

    await add(
      _PlatformerCompleteButton(
        text: 'RUN AGAIN',
        position: Vector2(game.size.x / 2, game.size.y * 0.53),
        onPressed: () {
          GameAudio.playButton();
          game.router.pushReplacementNamed('level-one');
        },
      ),
    );

    await add(
      _PlatformerCompleteButton(
        text: 'MAIN MENU',
        position: Vector2(game.size.x / 2, game.size.y * 0.65),
        onPressed: () {
          GameAudio.playButton();
          game.router.pushReplacementNamed('menu');
        },
      ),
    );
  }
}

class _PlatformerCompleteButton extends RectangleComponent with TapCallbacks {
  _PlatformerCompleteButton({
    required this.text,
    required Vector2 position,
    required this.onPressed,
  }) : super(
          position: position,
          size: Vector2(220, 58),
          anchor: Anchor.center,
          paint: Paint()..color = const Color(0xFF5A3A12),
        );

  final String text;
  final VoidCallback onPressed;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    await add(
      TextComponent(
        text: text,
        position: size / 2,
        anchor: Anchor.center,
        textRenderer: TextPaint(
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  @override
  void onTapUp(TapUpEvent event) {
    onPressed();
  }
}
