import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import 'wall.dart';

class Player extends PositionComponent {
  final Sprite? sprite;
  final List<Wall> platforms;
  final Vector2 worldSize;
  final Paint _fallbackPaint = Paint()..color = const Color(0xFF29C7FF);
  final Vector2 velocity = Vector2.zero();
  late Vector2 _spawnPosition;

  double _moveDirection = 0;
  bool _grounded = false;

  static const double moveSpeed = 260;
  static const double gravity = 1200;
  static const double jumpSpeed = 680;

  Player({
    this.sprite,
    required this.platforms,
    required this.worldSize,
  }) : super(
          size: Vector2(52, 64),
          anchor: Anchor.center,
        );

  bool get isUsingSprite => sprite != null;

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _spawnPosition = position.clone();
  }

  void setMoveDirection(double direction) {
    _moveDirection = direction.clamp(-1.0, 1.0).toDouble();
  }

  void jump() {
    if (!_grounded) return;
    velocity.y = -jumpSpeed;
    _grounded = false;
  }

  Rect _rectAt(Vector2 target) {
    return Rect.fromCenter(
      center: Offset(target.x, target.y),
      width: size.x,
      height: size.y,
    );
  }

  @override
  void update(double dt) {
    super.update(dt);

    velocity.x = _moveDirection * moveSpeed;
    velocity.y += gravity * dt;

    final halfWidth = size.x / 2;
    final nextX = (position.x + velocity.x * dt)
        .clamp(halfWidth, worldSize.x - halfWidth)
        .toDouble();
    position.x = nextX;

    final oldBottom = position.y + size.y / 2;
    final target = Vector2(position.x, position.y + velocity.y * dt);
    final targetRect = _rectAt(target);
    final nextBottom = target.y + size.y / 2;

    _grounded = false;

    if (velocity.y >= 0) {
      for (final platform in platforms) {
        final platformRect = Rect.fromLTWH(
          platform.position.x,
          platform.position.y,
          platform.size.x,
          platform.size.y,
        );

        final horizontalOverlap =
            targetRect.right > platformRect.left &&
            targetRect.left < platformRect.right;
        final crossedTop =
            oldBottom <= platformRect.top + 12 &&
            nextBottom >= platformRect.top;

        if (horizontalOverlap && crossedTop) {
          position.y = platformRect.top - size.y / 2;
          velocity.y = 0;
          _grounded = true;
          return;
        }
      }
    }

    position.y = target.y;

    if (position.y > worldSize.y + 180) {
      position.setFrom(_spawnPosition);
      velocity.setZero();
      _moveDirection = 0;
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final activeSprite = sprite;
    if (activeSprite != null) {
      activeSprite.render(canvas, size: size);
      return;
    }

    final rect = Rect.fromLTWH(0, 0, size.x, size.y);
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(12)),
      _fallbackPaint,
    );
  }
}
